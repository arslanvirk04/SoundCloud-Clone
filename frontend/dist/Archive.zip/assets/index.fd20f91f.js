import{c as t}from"./index.ed1e7a57.js";const o=({children:r})=>t("div",{className:"gap-y-8 grid pr-6",style:{marginBottom:100},children:r});export{o as C};
